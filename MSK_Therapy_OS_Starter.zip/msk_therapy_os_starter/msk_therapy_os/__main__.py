"""Zero-dependency synthetic-only MSK Therapy OS CLI prototype."""
from __future__ import annotations

import argparse
from datetime import date
import sqlite3
from pathlib import Path

ATLAS = 'https://CognitionLabSNUC.github.io/open-anatomy-atlas/'
RED_FLAGS = (
    'none',
    'progressive_weakness',
    'bowel_bladder_change',
    'saddle_numbness',
    'fever_with_spinal_pain',
    'major_trauma',
)


def open_db(path: str) -> sqlite3.Connection:
    db = sqlite3.connect(path)
    db.execute('PRAGMA foreign_keys=ON')
    return db


def init(db: sqlite3.Connection) -> None:
    db.executescript('''
        CREATE TABLE IF NOT EXISTS cases (
            case_id TEXT PRIMARY KEY,
            label TEXT NOT NULL CHECK (case_id LIKE 'DEMO-%')
        );
        CREATE TABLE IF NOT EXISTS visits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            case_id TEXT NOT NULL REFERENCES cases(case_id),
            visit_date TEXT NOT NULL,
            region TEXT NOT NULL,
            pain INTEGER NOT NULL CHECK (pain BETWEEN 0 AND 10),
            rom_deg REAL NOT NULL CHECK (rom_deg BETWEEN 0 AND 360),
            flag TEXT NOT NULL,
            note TEXT NOT NULL,
            disposition TEXT NOT NULL,
            created_utc TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
        );
    ''')
    db.commit()


def seed_demo(db: sqlite3.Connection) -> None:
    init(db)
    db.execute(
        'INSERT OR IGNORE INTO cases (case_id, label) VALUES (?, ?)',
        ('DEMO-NECK-001', 'Fictional neck discomfort learning scenario'),
    )
    db.execute(
        'INSERT OR IGNORE INTO cases (case_id, label) VALUES (?, ?)',
        ('DEMO-LOWBACK-002', 'Fictional low-back discomfort learning scenario'),
    )
    db.commit()


def add_visit(db: sqlite3.Connection, *, case: str, when: str, pain: int,
              rom: float, region: str, flag: str, note: str) -> str:
    # Explicitly reject non-demo identifiers in the educational-only starter.
    if not case.startswith('DEMO-'):
        raise ValueError('Synthetic DEMO-* case identifiers only; no real patients')
    date.fromisoformat(when)
    if pain not in range(11):
        raise ValueError('pain must be an integer between 0 and 10')
    if not (0 <= rom <= 360):
        raise ValueError('rom must be in degrees between 0 and 360')
    if flag not in RED_FLAGS:
        raise ValueError(f'flag must be one of: {", ".join(RED_FLAGS)}')
    if not region or not region.strip():
        raise ValueError('region is required')
    if len(note) > 500:
        raise ValueError('note must be <= 500 characters')
    if db.execute('SELECT 1 FROM cases WHERE case_id = ?', (case,)).fetchone() is None:
        raise ValueError('unknown DEMO case; run seed-demo')
    disposition = 'STOP_AND_REFER' if flag != 'none' else 'DOCUMENT_ONLY'
    db.execute(
        '''INSERT INTO visits (case_id,visit_date,region,pain,rom_deg,flag,note,disposition)
           VALUES (?,?,?,?,?,?,?,?)''',
        (case, when, region.strip(), pain, rom, flag, note, disposition),
    )
    db.commit()
    return disposition


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description='MSK-Therapy-OS, synthetic cases ONLY')
    sub = p.add_subparsers(dest='action', required=True)
    for action in ['init', 'seed-demo', 'cases', 'timeline']:
        command = sub.add_parser(action)
        command.add_argument('--db', default='demo.sqlite3')
        if action == 'timeline':
            command.add_argument('--case', required=True)
    visit = sub.add_parser('add-visit')
    visit.add_argument('--db', default='demo.sqlite3')
    visit.add_argument('--case', required=True)
    visit.add_argument('--date', dest='when', required=True)
    visit.add_argument('--pain', type=int, required=True)
    visit.add_argument('--rom', type=float, required=True)
    visit.add_argument('--region', required=True)
    visit.add_argument('--flag', required=True, choices=RED_FLAGS)
    visit.add_argument('--note', default='')
    sub.add_parser('atlas')
    return p


def main() -> int:
    args = parser().parse_args()
    print('DEMO ONLY: Do not enter or store real patient information.')
    if args.action == 'atlas':
        print(ATLAS)
        return 0
    if args.action != 'init' and not Path(args.db).exists():
        print('Database missing. Run init first.')
        return 2
    with open_db(args.db) as db:
        try:
            if args.action == 'init':
                init(db)
                print('Initialized synthetic-only demo database')
            elif args.action == 'seed-demo':
                seed_demo(db)
                print('Seeded fictional cases')
            elif args.action == 'cases':
                for row in db.execute('SELECT case_id,label FROM cases ORDER BY case_id'):
                    print(' | '.join(str(v) for v in row))
            elif args.action == 'add-visit':
                result = add_visit(db, case=args.case, when=args.when, pain=args.pain,
                                   rom=args.rom, region=args.region, flag=args.flag,
                                   note=args.note)
                print(result)
                if result == 'STOP_AND_REFER':
                    print('Red flag reported: do not proceed with manual/electrical interventions; seek qualified medical assessment.')
            elif args.action == 'timeline':
                if not args.case.startswith('DEMO-'):
                    raise ValueError('Synthetic DEMO-* cases only')
                rows = db.execute('''SELECT visit_date,region,pain,rom_deg,flag,disposition
                                     FROM visits WHERE case_id=? ORDER BY visit_date,id''',
                                  (args.case,)).fetchall()
                if not rows:
                    print('No synthetic visits found')
                for row in rows:
                    print(f'{row[0]} | {row[1]} | pain={row[2]}/10 | ROM={row[3]:g} deg | {row[4]} | {row[5]}')
        except (ValueError, sqlite3.Error) as error:
            print(f'ERROR: {error}')
            return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
