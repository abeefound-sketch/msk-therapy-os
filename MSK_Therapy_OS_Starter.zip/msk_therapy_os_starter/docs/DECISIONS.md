# Architecture decision record

## ADR-001 - One orchestration repo, upstream adapters

Status: Accepted for prototype. Rationale: smaller operational surface, stable interfaces, avoids licensing/upgrade conflicts.

## ADR-002 - SQLite and Python standard library first

Status: Accepted for synthetic prototype only. Rationale: 8 GB RAM laptop; zero external services. Revisit before patient use.

## ADR-003 - Safety rule engine before AI

Status: Accepted. Red flags are explicit and auditable. AI is read-only, optional, and must never override safety rules.

## ADR-004 - Educational anatomy viewer rather than diagnosis image engine

Status: Accepted. The atlas illustrates structures but cannot infer tissue injury or locate nerve compression from palpation.
