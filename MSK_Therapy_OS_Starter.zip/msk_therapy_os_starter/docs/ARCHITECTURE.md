# MSK-Therapy-OS: Architecture and boundaries

## Context

The system helps a learner understand anatomy and track fictional longitudinal musculoskeletal scenarios. A medically safe production deployment requires independent clinical, privacy, security and regulatory review. It **must never replace** a licensed assessment or control electric stimulation equipment.

## Compression rules

1. **One repository** for orchestration and learning workflows. Treat source atlases as external assets and healthcare backends as optional adapters.
2. **Four capabilities** rather than a microservice per domain: anatomy navigation; assessment and safety; visit log; education/evidence.
3. **One datastore** in the initial synthetic prototype, no event broker or distributed architecture.
4. **One authority per concern:** clinical reviewer owns safety definitions and evidence; anatomy data source owns structure taxonomy; future EHR owns patient identity; AI supplies optional explanations only.
5. **No autonomous actions** triggered by AI or screening heuristics.

## Component contracts

| Component | Input | Output | Explicitly excluded |
|---|---|---|---|
| AnatomyAdapter | Region and structure code | Source-qualified atlas link/annotation | Confirming cause of pain or nerve entrapment |
| Assessment | Operator-entered pain, ROM, symptoms | Structured observations | Automated diagnosis |
| SafetyGate | User-reported red flags and device warnings | STOP_AND_REFER / DOCUMENT_ONLY; reason | Claiming clearance when negative |
| SessionLog | Fictional visit and assessments | Dated visit records | Device recommendations |
| EvidenceLibrary | Human-curated citations | Explanations with provenance | Unsupported clinical claims |
| AI Tutor (future) | Deidentified/consented inputs + vetted sources | Explain/quiz/abstain with citations | Prescribe protocols, control DDS, overrule SafetyGate |
| FHIRAdapter (future) | Validated clinical resource mappings | FHIR payloads | Assuming conformity merely from JSON structure |

## Trust boundaries

- External atlas resources may have third-party content licenses. Keep source name, version and attribution visible; do not bundle or transform meshes without a specific license review.
- `--note` is free text: this starter **cannot technically prevent someone typing identifiable data into a note**. It is explicitly demonstration-only. Do not use the demo with real patients.
- A future production EHR integration needs end-to-end encryption, authentication, role authorization, immutable/auditable event history, backup recovery, consent, minimization, retention and regional compliance review.
- Device settings must come from a verified device manual and licensed operator documentation. No inferred equivalence between DDS, TENS and NMES.
- Thai massage, Dien Chan and meridian concepts must have distinct knowledge namespaces from modern neuro-musculoskeletal anatomy.

## Prototype state

The `atlas` CLI command currently prints a URL. The prototype does **not** embed a viewer, make API requests to upstream repositories or import 3D structure identifiers. The `--rom` field is an unspecialized synthetic number and **not** a clinically comparable ROM assessment; a proper instrument/side/motion schema is required in M1.

## Target hardware and performance

- Target: Windows x64, 8 GB RAM, integrated Intel HD 5500.
- CLI memory footprint is designed to remain small (Python stdlib and SQLite).
- Interactive 3D should start with BodyParts3D 4.0 and be benchmarked on the physical machine, not assumed to perform adequately.
- If rendering is poor, fall back to 2D diagrams or pre-rendered annotated images with source attribution.

## Clinical/safety hard gates

**Demo outcomes are only labels for safety training**, not triage advice. Escalation for true emergencies must follow local medical protocols. Absence of a stored flag does not mean the intervention is safe. The prototype does not ask a complete intake and cannot evaluate DDS-specific contraindications.

## ADR index

See `DECISIONS.md` for accepted architecture decisions. Record any future deviation with measurements, cost and human sign-off.
