# Evidence and license register (initial verification)

| Component/reference | Verified scope | Limitation / follow-up |
|---|---|---|
| https://github.com/CognitionLabSNUC/open-anatomy-atlas | Interactive anatomy UI; BodyParts3D 4.0/4.3 and Z-Anatomy; MIT app code | Full resolution requires modern GPU; body atlas not diagnostic |
| https://github.com/Z-Anatomy/Models-of-human-anatomy | Blender template; CC BY-SA models | Individual third-party meshes have differing license terms; review before distribution |
| https://github.com/medplum/medplum | FHIR healthcare platform | Full-stack example uses PostgreSQL, Redis, API and web app; defer for low-memory laptop |
| https://hl7.org/fhir/R4/questionnaireresponse.html | Structured questionnaires mapped to an encounter | Clinical data model requires review and security |
| https://www.fda.gov/regulatory-information/search-fda-guidance-documents/guidance-document-powered-muscle-stimulator-510ks-guidance-industry-fda-reviewersstaff-and | Warnings/contraindications for relevant powered muscle stimulators | Does **not** validate particular DDS machines; no dosage inference |

**No intervention efficacy claim is made by this starter.** Each future therapeutic claim needs independently evaluated clinical evidence.
