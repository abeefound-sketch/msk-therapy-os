# MSK-Therapy-OS (synthetic CLI starter)

**Educational and engineering proof of concept ONLY.** Do not enter patient names, identifiable details, or real medical data. Not suitable for clinical use, diagnosis, treatment or DDS machine control. See [SPEC.md](SPEC.md) for safety/security blockers and the implementation plan.

## Run (Python 3.10+; no pip dependencies)

On Windows PowerShell run `py -3 -m msk_therapy_os` in place of `python -m msk_therapy_os`:

```bash
python -m msk_therapy_os init --db demo.sqlite3
python -m msk_therapy_os seed-demo --db demo.sqlite3
python -m msk_therapy_os cases --db demo.sqlite3
python -m msk_therapy_os add-visit --db demo.sqlite3 --case DEMO-NECK-001 --date 2026-10-19 --pain 6 --rom 42 --region neck --flag none --note 'Fictional learning exercise'
python -m msk_therapy_os timeline --db demo.sqlite3 --case DEMO-NECK-001
python -m msk_therapy_os atlas
python -m unittest discover -s tests -v
```

For safety handling, record a synthetic red-flag scenario:

```bash
python -m msk_therapy_os add-visit --db demo.sqlite3 --case DEMO-NECK-001 --date 2026-10-20 --pain 8 --rom 25 --region neck --flag progressive_weakness --note 'Fictional safety drill'
```

This records `STOP_AND_REFER`. The demo does **not** determine clinical diagnoses or device suitability.

## Integrations: deliberately postponed

- [Open Anatomy Atlas](https://github.com/CognitionLabSNUC/open-anatomy-atlas) opened with `atlas` command. BodyParts3D 4.0 is preferable to very high-poly anatomy data on low-end GPU. No local model bundling.
- [Z-Anatomy](https://github.com/Z-Anatomy/Models-of-human-anatomy) is an optional **data source** already understood by the Atlas, not a second frontend.
- [Medplum](https://github.com/medplum/medplum) is optional for secure FHIR-backed case management later. This demo **does not integrate or run Medplum**.

## Current limits

No graphical body map, no real SOAP workflows, no AI Tutor, no imaging, no patient identity / consent, no access controls, no encryption, no audit trails, no regulatory or clinical validation. These are deliberate gates, not hidden features.
